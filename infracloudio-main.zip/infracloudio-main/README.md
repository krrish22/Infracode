# infracloudio
# infracloudio

Commands run to setup the docker image
1. Run docker pull to fetch the docker image 'docker pull infracloudio/csvserver:latest'
2. Execute the gencsv.sh to generate the inputFile
3. Run the docker image with the command 'docker run -d -p 9393:9300 -e CSVSERVER_BORDER=ORANGE -v /root/infracloudio/solution/inputFile:/csvserver/inputdata infracloudio/csvserver:latest'

