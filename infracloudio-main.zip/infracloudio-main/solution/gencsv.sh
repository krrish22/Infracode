i=0
j=10
rm inputFile 2> /dev/null
touch inputFile
chmod 755 inputFile
while [ $i -lt $j ]
do
  echo "$i, $RANDOM" >> inputFile
  ((i++))
done
